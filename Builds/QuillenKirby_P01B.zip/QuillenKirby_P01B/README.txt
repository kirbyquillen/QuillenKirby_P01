hi king its kirby you already know what time it is

https://github.com/kirbyquillen/QuillenKirby_P01

controls:
W forward
A left
S right
D back

Space: shoot
Backspace: reset
ESC: exit

alright so i really struggled with the particle effects (i don't know
why they hate me i can never make them work) and for some reason my navigation...
is not quite working yet. the ground appears to kill the enemy.
to show that the enemy can be damaged there is a stationary enemy
for you to shoot and kill. and then you can destroy the walls and
drive off the side. really what more could you want